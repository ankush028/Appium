module.exports = {
  arrowParens: 'always',
  bracketSameLine: false,
  bracketSpacing: true,
  singleQuote: true,
  trailingComma: 'es5',
  semi: true,
  printWidth: 80,
  tabWidth: 2,
  useTabs: false,
};


export const GOOGLE_MAP_API = 'YOUR_GOOGLE_MAP_API_KEY'
export const BASE_URL = 'http://localhost:3000/api'
export const SOCKET_URL = 'http://localhost:3000'


// USE YOUR NETWORK IP OR HOSTED URL
// export const BASE_URL = 'http://172.20.10.4:3000/api'
// export const SOCKET_URL = 'http://172.20.10.4:3000'

